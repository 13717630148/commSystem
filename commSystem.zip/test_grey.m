function output = test_grey(input)
temp = grey(input);
output = igrey(temp);
end