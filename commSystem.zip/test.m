a = [1,2,3,4]
switch a
	case [1, 2, 3, 4]
        disp('Invalid score')
end