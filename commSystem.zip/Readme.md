It is the code for the 3rd home work of the stupid 
communication system course.

It is not only poorly written, but also contains no real fruit.

Therefore, I strongly recommend that you not copy this work!
